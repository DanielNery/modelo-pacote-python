# Modelo de pacote Python

    - Modelo Básico de pacote Python
    - Serve para criação de pacotes e bibliotecas Python
    - Faz um hello world no terminal
    - pip install helloworld_daniel_package